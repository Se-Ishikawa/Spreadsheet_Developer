from __future__ import annotations

from copy import deepcopy

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


def _parse_alignment(alignment: Alignment | None) -> str | None:
    if alignment is None:
        return None
    if alignment.horizontal in {"center", "centerContinuous", "distributed", "fill", "justify"}:
        return "center"
    if alignment.horizontal == "right":
        return "right"
    if alignment.horizontal == "left":
        return "left"
    return None


def _parse_number_format(fmt: str | None) -> dict | None:
    if not fmt:
        return None
    fmt = fmt.strip()
    lower = fmt.lower()
    if lower in {"general", "@"}:
        return None
    if "%" in fmt:
        decimals = fmt.split(".")[-1].count("0") if "." in fmt else 0
        return {"type": "percent", "decimals": decimals, "thousands": "," in fmt}
    if "¥" in fmt or "[$¥" in fmt:
        decimals = fmt.split(".")[-1].count("0") if "." in fmt else 0
        return {"type": "currency", "decimals": decimals, "thousands": "," in fmt}
    if any(token in lower for token in ["yy", "mm", "dd"]):
        return {"type": "date", "decimals": 0, "thousands": False}
    if any(token in lower for token in ["hh", "ss"]):
        return {"type": "time", "decimals": 0, "thousands": False}
    if any(ch in fmt for ch in "0#"):
        decimals = fmt.split(".")[-1].count("0") if "." in fmt else 0
        return {"type": "number", "decimals": decimals, "thousands": "," in fmt}
    return None


def load_xlsx(file_path: str) -> dict[str, dict]:
    wb = load_workbook(file_path, data_only=False)
    result: dict[str, dict] = {}
    for ws in wb.worksheets:
        rows: list[list[str]] = []
        max_row = ws.max_row or 1
        max_col = ws.max_column or 1
        styles: dict[str, dict] = {}
        for r in range(1, max_row + 1):
            row_vals = []
            for c in range(1, max_col + 1):
                cell = ws.cell(r, c)
                value = cell.value
                row_vals.append("" if value is None else str(value))
                style: dict = {}
                if cell.font:
                    if cell.font.bold:
                        style["bold"] = True
                    if cell.font.italic:
                        style["italic"] = True
                    if cell.font.underline and cell.font.underline != "none":
                        style["underline"] = True
                    if cell.font.sz:
                        style["font_size"] = int(cell.font.sz)
                    if cell.font.color and getattr(cell.font.color, "type", None) == "rgb" and cell.font.color.rgb:
                        style["fg"] = f"#{cell.font.color.rgb[-6:]}"
                if cell.fill and cell.fill.fill_type == "solid" and cell.fill.fgColor and getattr(cell.fill.fgColor, "type", None) == "rgb" and cell.fill.fgColor.rgb:
                    style["bg"] = f"#{cell.fill.fgColor.rgb[-6:]}"
                halign = _parse_alignment(cell.alignment)
                if halign:
                    style["halign"] = halign
                if cell.border:
                    borders = {}
                    for side_name in ["left", "top", "right", "bottom"]:
                        side = getattr(cell.border, side_name)
                        if side and side.style:
                            borders[side_name] = True
                    if borders:
                        style["borders"] = borders
                numfmt = _parse_number_format(cell.number_format)
                if numfmt:
                    style["number_format"] = numfmt
                if style:
                    styles[f"{r - 1},{c - 1}"] = deepcopy(style)
            rows.append(row_vals)
        result[ws.title] = {"rows": max_row, "cols": max_col, "data": rows or [[""]], "styles": styles}
    return result


def _apply_style(cell, style: dict) -> None:
    font_kwargs = {}
    if style.get("bold"):
        font_kwargs["bold"] = True
    if style.get("italic"):
        font_kwargs["italic"] = True
    if style.get("underline"):
        font_kwargs["underline"] = "single"
    if style.get("font_size"):
        font_kwargs["sz"] = style.get("font_size")
    if style.get("fg"):
        font_kwargs["color"] = style["fg"].replace("#", "")
    if font_kwargs:
        cell.font = Font(**font_kwargs)
    if style.get("bg"):
        rgb = style["bg"].replace("#", "")
        cell.fill = PatternFill(fill_type="solid", fgColor=rgb)
    if style.get("halign"):
        cell.alignment = Alignment(horizontal=style["halign"])
    borders = style.get("borders") or {}
    if borders:
        thin = Side(style="thin", color="000000")
        cell.border = Border(
            left=thin if borders.get("left") else Side(style=None),
            right=thin if borders.get("right") else Side(style=None),
            top=thin if borders.get("top") else Side(style=None),
            bottom=thin if borders.get("bottom") else Side(style=None),
        )
    numfmt = style.get("number_format")
    if isinstance(numfmt, dict):
        ftype = numfmt.get("type", "general")
        decimals = int(numfmt.get("decimals", 2))
        thousands = bool(numfmt.get("thousands", False))
        if ftype == "number":
            cell.number_format = ("#,##0" if thousands else "0") + ("." + "0" * decimals if decimals else "")
        elif ftype == "percent":
            cell.number_format = ("#,##0" if thousands else "0") + ("." + "0" * decimals if decimals else "") + "%"
        elif ftype == "currency":
            cell.number_format = '[$¥-411]' + (("#,##0" if thousands else "0") + ("." + "0" * decimals if decimals else ""))
        elif ftype == "date":
            cell.number_format = "yyyy-mm-dd"
        elif ftype == "time":
            cell.number_format = "hh:mm:ss"


def save_xlsx(file_path: str, sheets: dict[str, dict | list[list[str]]]) -> None:
    wb = Workbook()
    first = True
    for name, sheet_payload in sheets.items():
        ws = wb.active if first else wb.create_sheet()
        ws.title = name
        first = False
        if isinstance(sheet_payload, list):
            matrix = sheet_payload
            styles = {}
        else:
            matrix = sheet_payload.get("data", [])
            styles = sheet_payload.get("styles", {})
        for r, row in enumerate(matrix, start=1):
            for c, value in enumerate(row, start=1):
                cell = ws.cell(r, c)
                cell.value = value
                style = styles.get(f"{r - 1},{c - 1}")
                if style:
                    _apply_style(cell, style)
    wb.save(file_path)
