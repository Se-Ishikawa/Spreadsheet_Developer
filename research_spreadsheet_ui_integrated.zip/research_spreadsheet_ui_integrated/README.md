# PySide Research Spreadsheet Phase5-7

This package includes:
- Phase 5: ribbon-like toolbar and active-cell border emphasis
- Phase 6: expanded formula engine
- Phase 7: embedded chart creation environment

## Run

```bash
pip install -r requirements.txt
python main.py
```

## Main features
- Ribbon-like UI with Home / Insert / Data / Chart tabs
- Multi-sheet workbook with add/rename/delete sheet actions
- Formula bar and A1 name box navigation
- Active-cell border highlight
- Undo / Redo for cell edits, clear, paste, row/column insertion/deletion
- CSV / XLSX / JSON project load and save
- Functions:
  - SUM, AVERAGE, MIN, MAX, COUNT
  - MEDIAN, STDEV, VAR
  - ABS, ROUND, SQRT, POWER
  - IF, AND, OR, NOT
  - LEN, LEFT, RIGHT, MID, CONCAT
  - TODAY, YEAR, MONTH, DAY
- Cell/range references such as `=A1+B1`, `=SUM(A1:A10)`, `=IF(A1>10, "OK", "NG")`
- Chart dialog:
  - Scatter, Line, Bar, Histogram
  - Plot from selected columns or manually selected X/Y columns

## Notes
- This is not full Excel compatibility.
- Formula evaluation is intentionally sandboxed and limited to the built-in function set.
- Formatting is intentionally lightweight in this package and focuses on the requested Phase5-7 work.
