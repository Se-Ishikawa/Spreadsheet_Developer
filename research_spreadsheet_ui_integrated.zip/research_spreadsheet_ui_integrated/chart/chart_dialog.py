from __future__ import annotations

from typing import Sequence

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QMessageBox,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)


class ChartDialog(QDialog):
    def __init__(self, parent=None, headers: Sequence[str] = (), data: list[list[str]] | None = None, selected_cols: list[int] | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Create Chart")
        self.resize(980, 680)
        self.headers = list(headers)
        self.data = data or []
        self.selected_cols = selected_cols or []

        root = QVBoxLayout(self)
        controls = QWidget()
        form = QFormLayout(controls)

        self.chart_type = QComboBox()
        self.chart_type.addItems([
            "Scatter",
            "Line",
            "Bar",
            "Horizontal Bar",
            "Histogram",
            "Area",
            "Step",
            "Boxplot",
            "Heatmap",
            "Pie",
            "Scatter + Fit",
            "Multi-Line",
        ])
        self.x_combo = QComboBox()
        self.y_combo = QComboBox()
        self.x_combo.addItems(self.headers)
        self.y_combo.addItems(self.headers)

        default_x = self.selected_cols[0] if len(self.selected_cols) >= 1 else 0
        default_y = self.selected_cols[1] if len(self.selected_cols) >= 2 else (1 if len(self.headers) > 1 else 0)
        self.x_combo.setCurrentIndex(default_x)
        self.y_combo.setCurrentIndex(default_y)

        self.bins_spin = QSpinBox()
        self.bins_spin.setRange(3, 200)
        self.bins_spin.setValue(15)

        self.trend_check = QCheckBox("Show linear trendline")
        self.grid_check = QCheckBox("Show grid")
        self.grid_check.setChecked(True)

        form.addRow("Chart Type", self.chart_type)
        form.addRow("X Column", self.x_combo)
        form.addRow("Y Column", self.y_combo)
        form.addRow("Bins", self.bins_spin)
        form.addRow("Options", self.trend_check)
        form.addRow("", self.grid_check)

        self.figure = Figure()
        self.canvas = FigureCanvasQTAgg(self.figure)

        btns = QDialogButtonBox(QDialogButtonBox.Close)
        plot_btn = btns.addButton("Plot", QDialogButtonBox.ActionRole)
        plot_btn.clicked.connect(self.plot)
        btns.rejected.connect(self.reject)

        root.addWidget(controls)
        root.addWidget(self.canvas, 1)
        root.addWidget(btns)

        self.chart_type.currentTextChanged.connect(self._on_chart_type_changed)
        self._on_chart_type_changed(self.chart_type.currentText())
        self.plot()

    def _on_chart_type_changed(self, chart: str) -> None:
        histogram_like = chart in {"Histogram"}
        no_y = chart in {"Histogram", "Boxplot", "Heatmap", "Pie", "Multi-Line"}
        self.bins_spin.setEnabled(histogram_like)
        self.y_combo.setEnabled(not no_y)

    def _extract_numeric_column(self, idx: int) -> list[float]:
        vals = []
        for row in self.data:
            if idx >= len(row):
                continue
            try:
                vals.append(float(row[idx]))
            except Exception:
                pass
        return vals

    def _extract_text_column(self, idx: int) -> list[str]:
        vals = []
        for row in self.data:
            if idx >= len(row):
                continue
            value = str(row[idx]).strip()
            if value != "":
                vals.append(value)
        return vals

    def _extract_numeric_matrix(self, cols: list[int]) -> list[list[float]]:
        matrix = []
        for row in self.data:
            vals = []
            ok = True
            for col in cols:
                if col >= len(row):
                    ok = False
                    break
                try:
                    vals.append(float(row[col]))
                except Exception:
                    ok = False
                    break
            if ok:
                matrix.append(vals)
        return matrix

    def _selected_numeric_columns(self) -> list[int]:
        cols = self.selected_cols if self.selected_cols else [self.x_combo.currentIndex(), self.y_combo.currentIndex()]
        return [c for c in cols if 0 <= c < len(self.headers)]

    def _plot_trendline(self, ax, x: list[float], y: list[float]) -> None:
        n = min(len(x), len(y))
        if n < 2:
            return
        x = x[:n]
        y = y[:n]
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        den = sum((a - mean_x) ** 2 for a in x)
        if den == 0:
            return
        slope = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y)) / den
        intercept = mean_y - slope * mean_x
        xs = [min(x), max(x)]
        ys = [slope * xi + intercept for xi in xs]
        ax.plot(xs, ys)

    def plot(self) -> None:
        x_idx = self.x_combo.currentIndex()
        y_idx = self.y_combo.currentIndex()
        chart = self.chart_type.currentText()
        x = self._extract_numeric_column(x_idx)
        y = self._extract_numeric_column(y_idx)
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        try:
            if chart == "Histogram":
                series = x if x else y
                if not series:
                    raise ValueError("No numeric data to plot.")
                ax.hist(series, bins=self.bins_spin.value())
                ax.set_xlabel(self.headers[x_idx] if x else self.headers[y_idx])
                ax.set_ylabel("Count")

            elif chart == "Boxplot":
                cols = self._selected_numeric_columns()
                if not cols:
                    raise ValueError("Select at least one numeric column.")
                datasets = []
                labels = []
                for col in cols:
                    vals = self._extract_numeric_column(col)
                    if vals:
                        datasets.append(vals)
                        labels.append(self.headers[col])
                if not datasets:
                    raise ValueError("No numeric data to plot.")
                ax.boxplot(datasets, labels=labels)
                ax.set_ylabel("Value")

            elif chart == "Heatmap":
                cols = self._selected_numeric_columns()
                if len(cols) < 2:
                    raise ValueError("Select at least two numeric columns for a heatmap.")
                matrix = self._extract_numeric_matrix(cols)
                if not matrix:
                    raise ValueError("No numeric data to plot.")
                im = ax.imshow(matrix, aspect="auto")
                self.figure.colorbar(im, ax=ax)
                ax.set_xticks(range(len(cols)))
                ax.set_xticklabels([self.headers[c] for c in cols])
                ax.set_ylabel("Row")

            elif chart == "Pie":
                labels = self._extract_text_column(x_idx)
                values = self._extract_numeric_column(y_idx)
                n = min(len(labels), len(values))
                if n == 0:
                    raise ValueError("Pie chart requires text labels and numeric values.")
                ax.pie(values[:n], labels=labels[:n], autopct="%1.1f%%")

            elif chart == "Multi-Line":
                cols = self._selected_numeric_columns()
                if len(cols) < 2:
                    raise ValueError("Select at least two numeric columns.")
                row_count = max(len(self._extract_numeric_column(c)) for c in cols)
                xs = list(range(1, row_count + 1))
                for col in cols:
                    series = self._extract_numeric_column(col)
                    if series:
                        ax.plot(xs[:len(series)], series, label=self.headers[col])
                ax.set_xlabel("Index")
                ax.set_ylabel("Value")
                ax.legend()

            else:
                n = min(len(x), len(y))
                if n == 0:
                    raise ValueError("No numeric data to plot.")
                x = x[:n]
                y = y[:n]
                if chart == "Scatter":
                    ax.scatter(x, y)
                elif chart == "Scatter + Fit":
                    ax.scatter(x, y)
                    self._plot_trendline(ax, x, y)
                elif chart == "Line":
                    ax.plot(x, y)
                elif chart == "Bar":
                    ax.bar(x, y)
                elif chart == "Horizontal Bar":
                    ax.barh(x, y)
                elif chart == "Area":
                    ax.fill_between(x, y, alpha=0.4)
                    ax.plot(x, y)
                elif chart == "Step":
                    ax.step(x, y, where="mid")

                if chart == "Scatter" and self.trend_check.isChecked():
                    self._plot_trendline(ax, x, y)
                ax.set_xlabel(self.headers[x_idx])
                ax.set_ylabel(self.headers[y_idx])

            ax.set_title(chart)
            ax.grid(self.grid_check.isChecked())
            self.figure.tight_layout()
            self.canvas.draw()
        except Exception as e:
            QMessageBox.warning(self, "Plot Error", str(e))
